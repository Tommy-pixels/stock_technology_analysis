# Developing

If you already cloned the repository, you know that you need to deep dive in the code, here are some guidelines to set up your environment.
