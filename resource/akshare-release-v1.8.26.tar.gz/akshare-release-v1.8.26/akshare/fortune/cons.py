#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Date: 2021/6/30 19:55
Desc: fortune 配置文件
"""
# fortune
url_2020 = "http://www.fortunechina.com/fortune500/c/2020-08/10/content_372148.htm"
url_2019 = "http://www.fortunechina.com/fortune500/c/2019-07/22/content_339535.htm"
url_2018 = "http://www.fortunechina.com/fortune500/c/2018-07/19/content_311046.htm"
url_2017 = "http://www.fortunechina.com/fortune500/c/2017-07/20/content_286785.htm"
url_2016 = "http://www.fortunechina.com/fortune500/c/2016-07/20/content_266955.htm"
url_2015 = "http://www.fortunechina.com/fortune500/c/2015-07/22/content_244435.htm"
url_2014 = "http://www.fortunechina.com/fortune500/c/2014-07/07/content_212535.htm"
url_2013 = "http://www.fortunechina.com/fortune500/c/2013-07/08/content_164375.htm"  # 分 5 页
url_2012 = "http://www.fortunechina.com/fortune500/c/2012-07/09/content_106535.htm"  # 分 5 页
url_2011 = "http://www.fortunechina.com/fortune500/c/2011-07/07/content_62335.htm"  # 分 5 页
url_2010 = "http://www.fortunechina.com/fortune500/c/2010-07/09/content_38195.htm"  # 分 5 页
url_2009 = "http://www.fortunechina.com/fortune500/c/2009-07/08/content_21391.htm"  # 分 10 页
url_2008 = "http://www.fortunechina.com/fortune500/c/2008-10/15/content_12413.htm"  # 分 10 页
url_2007 = "http://www.fortunechina.com/fortune500/c/2007-10/15/content_9517.htm"  # 分 10 页
url_2006 = "http://www.fortunechina.com/fortune500/c/2006-10/01/content_9539.htm"
url_2005 = "http://www.fortunechina.com/fortune500/c/2005-10/01/content_9561.htm"
url_2004 = "http://www.fortunechina.com/fortune500/c/2004-10/01/content_9581.htm"
url_2003 = "http://www.fortunechina.com/fortune500/c/2003-10/01/content_9595.htm"
url_2002 = "http://www.fortunechina.com/fortune500/c/2002-10/01/content_9605.htm"
url_2001 = "http://www.fortunechina.com/fortune500/c/2001-11/01/content_9614.htm"
url_2000 = "http://www.fortunechina.com/fortune500/c/2000-12/01/content_9624.htm"
url_1999 = "http://www.fortunechina.com/fortune500/c/1999-10/01/content_9626.htm"
url_1998 = "http://www.fortunechina.com/fortune500/c/1998-10/11/content_9640.htm"
url_1997 = "http://www.fortunechina.com/fortune500/c/1997-11/12/content_9657.htm"
url_1996 = "http://www.fortunechina.com/fortune500/c/1996-11/01/content_9659.htm"
